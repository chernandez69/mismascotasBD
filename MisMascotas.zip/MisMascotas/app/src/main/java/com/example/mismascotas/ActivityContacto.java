package com.example.mismascotas;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.EditText;


import org.w3c.dom.Text;

public class ActivityContacto extends AppCompatActivity {
    private EditText editTextEmail;
    private EditText editTextMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);
        editTextEmail = (EditText) findViewById(R.id.edmail);
        editTextMessage = (EditText) findViewById(R.id.edcomenta);
       // buttonSend = (Button) findViewById(R.id.btnenvia);
       // buttonSend.setOnClickListener(this);
    }
    public void sendEmail(View v) {
        //metodo que envia los parametros a la clase enviarMail
        String email = editTextEmail.getText().toString().trim();
        String message = editTextMessage.getText().toString().trim();
        SendMail sm = new SendMail(this, email, message);
        sm.execute();
    }

    public void regresaMain(View v){
        Intent d = new Intent(this, MainActivity.class);
        startActivity(d);
        finish();
    }
}