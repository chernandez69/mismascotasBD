package com.example.mismascotas;
//clase que contiene el email y clave
//para qe funcione el codigo debes poner tu email y clave aqui.
public class Config {
        public static final String EMAIL ="xxxx1@gmail.com";
        public static final String PASSWORD ="xxxxx";
}
