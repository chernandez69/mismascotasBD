package com.example.mismascotas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.mismascotas.adapter.PageAdapter;
import com.example.mismascotas.fragment.RateadasViewFragment;
import com.example.mismascotas.fragment.RecyclerViewFragment;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //ArrayList<Mascota> mascotas;
    //declaramos el reciclerview
    //private RecyclerView listaMascotas;
    private androidx.appcompat.widget.Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        androidx.appcompat.widget.Toolbar miActionBar = findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);//para que se vea bien en todas las pantalla
        //variables para el fragment
        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        //instanciamos el reciclerview
        //listaMascotas = (RecyclerView) findViewById(R.id.rvMascotas);
        //creamos un linearlayout manager para las listas
        //LinearLayoutManager llm = new LinearLayoutManager(this);
        //llm.setOrientation(LinearLayoutManager.VERTICAL);
       // GridLayoutManager glm = new GridLayoutManager(this, 2);
        //listaMascotas.setLayoutManager(llm);//hacemos que el reciclerview se porte como linearL
        setUpViewPager();
        //validadmos el toolbar qe no sea nulo
        if(toolbar != null){
            setSupportActionBar(toolbar);
        }

    }//oncreate

    private ArrayList<Fragment> agregarFragments(){
        ArrayList<Fragment> fragments = new ArrayList<>();
        fragments.add(new RecyclerViewFragment());
        fragments.add(new RateadasViewFragment());
        return fragments;
    }
    private void setUpViewPager(){
        //agregamos el fragment al adapter
        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(),2, agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.emailico);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_like);

    }//setupviewpager

    //menu de opciones
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.mContact:
                Intent i=new Intent(this, ActivityContacto.class);
                startActivity(i);
                break;
            case R.id.mAbout:
                Intent intent=new Intent(this, ActivityAbout.class);
                startActivity(intent);
                break;
            case R.id.mSalir:
                 finish();
                break;

        }//switch

        return super.onOptionsItemSelected(item);
    }

}//main