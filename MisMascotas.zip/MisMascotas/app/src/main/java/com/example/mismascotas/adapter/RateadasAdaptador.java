package com.example.mismascotas.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mismascotas.pojo.Mascota;
import com.example.mismascotas.R;

import java.util.ArrayList;

public class RateadasAdaptador extends RecyclerView.Adapter<RateadasAdaptador.RateadasViewHolder>{
    ArrayList<Mascota> mascotas;
    Activity activity;
    public RateadasAdaptador(ArrayList<Mascota> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }

    //inflar el layout y lo pasara al viewholder para que obtenga los views
    @NonNull
    @Override
    public RateadasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_rateadas, parent, false);
        return new RateadasViewHolder(v) ;//pasamos el layout creado como un view
    }
    //asocia cada elemento de la vista con cada view
    @Override
    public void onBindViewHolder(@NonNull final RateadasViewHolder mascotaViewHolder, final int position) {
        //seteamos cada uno de los elementos que trae la lista
        final Mascota mascota = mascotas.get(position);
        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());//acceder al get foto
        mascotaViewHolder.tvNombreCV.setText(mascota.getNombre());
        mascotaViewHolder.tvRatinCV.setText(String.valueOf(mascota.getRatin()));
    }

    @Override
    public int getItemCount() {//cantidad de elementos de la lista
        return mascotas.size();
    }

    public static class RateadasViewHolder extends RecyclerView.ViewHolder{
        private ImageView imgFoto;
        private TextView tvNombreCV;
        private TextView tvRatinCV;

        public RateadasViewHolder(@NonNull View itemView) {
            super(itemView);
            imgFoto      = (ImageView) itemView.findViewById(R.id.imgfoto);
            tvNombreCV   = (TextView) itemView.findViewById(R.id.tvNombreCV);
            tvRatinCV    = (TextView) itemView.findViewById(R.id.tvRatinCV);
        }
    }
}