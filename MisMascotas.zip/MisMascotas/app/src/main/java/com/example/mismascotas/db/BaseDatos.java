package com.example.mismascotas.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {
    private Context context;

    public BaseDatos(Context context) {
        //definimos nombre y version db
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context = context;
    }
        @Override
        public void onCreate (SQLiteDatabase db){
            //creamos la estuctura de la base de datos tablas, etc
            String queryCrearTablaMascota = "CREATE TABLE " + ConstantesBaseDatos.TABLE_MASCOTAS + "(" +
                    ConstantesBaseDatos.TABLE_MASCOTAS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE + " TEXT, " +
                    ConstantesBaseDatos.TABLE_MASCOTAS_RAZA + " TEXT, " +
                    ConstantesBaseDatos.TABLE_MASCOTAS_FOTO + " INTEGER" +
                    ")";
            String queryCrearTablaLikesMascota = "CREATE TABLE " + ConstantesBaseDatos.TABLE_RATIN_MASCOTA + "(" +
                    ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID_MASCOTA + " INTEGER, " +
                    ConstantesBaseDatos.TABLE_RATIN_MASCOTA_NUMERO_RATIN + " INTEGER, " +
                    "FOREIGN KEY(" + ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID_MASCOTA + ") " +
                    "REFERENCES " + ConstantesBaseDatos.TABLE_MASCOTAS + "(" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + ")" +
                    ")";
            //ejecutamos el query para crear la bd
            db.execSQL(queryCrearTablaMascota);
            //cremos la estructura de la tabla contacto_likes
            db.execSQL(queryCrearTablaLikesMascota);
        }//oncreate

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            //afecta a la base de datos la elimina si exists
            db.execSQL("DROP TABLE IF EXISTS "+ ConstantesBaseDatos.TABLE_MASCOTAS);
            db.execSQL("DROP TABLE IF EXISTS "+ ConstantesBaseDatos.TABLE_RATIN_MASCOTA);
            //vuelve a crear la bd
            onCreate(db);
        }//on upgrade

    public ArrayList<Mascota> obtenerTodasLasMascotas(){
        ArrayList<Mascota> mascotas = new ArrayList<>();
        //ejecutamos el query para las mascotas
        String query = "SELECT * FROM " + ConstantesBaseDatos.TABLE_MASCOTAS;
        //abrimos la bd
        SQLiteDatabase db = this.getWritableDatabase();
        //creamos un cursor para recorre los datos
        Cursor regitros = db.rawQuery(query, null);
        //recorremos los registros con while
        while (regitros.moveToNext()){
            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(regitros.getInt(0));
            mascotaActual.setNombre(regitros.getString(1));
            mascotaActual.setRaza(regitros.getString(2));
            mascotaActual.setFoto(regitros.getInt(3));

            //traemos los ratings de la bd mascota rating al inicia la app
            String queryLikes = "SELECT COUNT("+ConstantesBaseDatos.TABLE_RATIN_MASCOTA_NUMERO_RATIN +") as ratin "+
                    " FROM " + ConstantesBaseDatos.TABLE_RATIN_MASCOTA +
                    " WHERE " + ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID_MASCOTA + "=" + mascotaActual.getId();
            Cursor registrosRatin = db.rawQuery(queryLikes, null);
            if (registrosRatin.moveToNext()){
                mascotaActual.setRatin(registrosRatin.getInt(0));
            }else{
                mascotaActual.setRatin(0);
            }
            mascotas.add(mascotaActual);
        }
        db.close();//cerrar luego de query
        return mascotas;
    }//obtener todas

    //obtener las mascotas rateadas aquiuiiii
    public ArrayList<Mascota> obtenerMascotasRateadas(){
        /*
        select  nombre, raza, foto  from mascota as A, mascota_ratin as B  where (A.id=B.id_mascota)
        and (B.numero_ratins>0) ORDER BY B.numero_ratins DESC LIMIT 5
         */
        ArrayList<Mascota> mascotaRateada = new ArrayList<>();
        //ejecutamos el query para las mascotas
        String query = "SELECT  ID_MASCOTA, NOMBRE, RAZA, FOTO, NUMERO_RATINS FROM MASCOTA AS A, MASCOTA_RATIN AS B WHERE "+
                "A.ID=B.ID_MASCOTA AND (B.NUMERO_RATINS>0) ORDER BY (B.NUMERO_RATINS) DESC LIMIT 5";
        //abrimos la bd
        SQLiteDatabase db = this.getWritableDatabase();
        //creamos un cursor para recorre los datos
        Cursor regitros = db.rawQuery(query, null);
        //recorremos los registros con while
        while (regitros.moveToNext()){
            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(regitros.getInt(0));
            mascotaActual.setNombre(regitros.getString(1));
            mascotaActual.setRaza(regitros.getString(2));
            mascotaActual.setFoto(regitros.getInt(3));
            mascotaActual.setRatin(regitros.getInt(4));

            //traemos los ratings de la bd mascota rating al inicia la app
            String queryRateadas = "SELECT COUNT("+ConstantesBaseDatos.TABLE_RATIN_MASCOTA_NUMERO_RATIN +") as ratin "+
                    " FROM " + ConstantesBaseDatos.TABLE_RATIN_MASCOTA +
                    " WHERE " + ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID_MASCOTA + "=" + mascotaActual.getId();
                    //+ " AND "+ConstantesBaseDatos.TABLE_RATIN_MASCOTA_NUMERO_RATIN +" >0 ";
            Cursor registrosRatin = db.rawQuery(queryRateadas, null);
            if (registrosRatin.moveToNext()){
                mascotaActual.setRatin(registrosRatin.getInt(0));
            }else{
                mascotaActual.setRatin(0);
            }
            mascotaRateada.add(mascotaActual);
        }
        db.close();//cerrar luego de query
        return mascotaRateada;

    }//obtener rateadas

    //metodo insertar datos
    public void insertarMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        //el metodo value hace referencia al campo y valor
        db.insert(ConstantesBaseDatos.TABLE_MASCOTAS, null, contentValues);
        db.close();
    }//insertar

    public void insertarRatinMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        //el metodo value hace referencia al campo y valor
        db.insert(ConstantesBaseDatos.TABLE_RATIN_MASCOTA, null, contentValues);
        db.close();
    }//insertar like

    public int obtenerRatinMascota(Mascota mascota){
        //obtener la suma de los likes de la bd
        int ratin =0;
        String query = "SELECT COUNT("+ConstantesBaseDatos.TABLE_RATIN_MASCOTA_NUMERO_RATIN+")"+
                " FROM "+ ConstantesBaseDatos.TABLE_RATIN_MASCOTA +
                " WHERE "+ ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID_MASCOTA + "="
                + mascota.getId();
        SQLiteDatabase db = this.getWritableDatabase();
        //recuperamos el query con un cursor
        Cursor registros= db.rawQuery(query, null);
        if(registros.moveToNext()){
            //recuperamos los registros
            ratin=registros.getInt(0);
        }//if
        db.close();
        return ratin;
    }//obtenerlistamascota
}//class
