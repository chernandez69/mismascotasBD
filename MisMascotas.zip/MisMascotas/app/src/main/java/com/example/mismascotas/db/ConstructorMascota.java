package com.example.mismascotas.db;

import android.content.ContentValues;
import android.content.Context;

import com.example.mismascotas.R;
import com.example.mismascotas.pojo.Mascota;
import java.util.ArrayList;

public class ConstructorMascota {
    private static final int RATING = 1;
    private Context context;
    //constructor mascota
    public ConstructorMascota(Context context) {
        this.context=context;
    }
    public ArrayList<Mascota> obtenerDatos(){

        //instanciamos la clase base datos para traer los contactos de la fuente
        BaseDatos db = new BaseDatos(context);
        insertar_Mascotas(db);
        return db.obtenerTodasLasMascotas();
    }

    public void insertar_Mascotas(BaseDatos db){
        //agregar contacto a la bd, genramos objeto content value
        ContentValues contentValues = new ContentValues();
        //con put guardamos los valores en la bse datos
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE,"Puffy");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAZA,"Buldog");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.ic1);
        //llamamos al metodo insertarmacota
        db.insertarMascota(contentValues);

        //con put guardamos los valores en la bse datos
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE,"Ruffo");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAZA,"Coker Spanish");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.ic2);
        //llamamos al metodo insertarmacota
        db.insertarMascota(contentValues);

        //con put guardamos los valores en la bse datos
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE,"Zulingo");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAZA,"Fox Terrier");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.ic3);
        //llamamos al metodo insertarmacota
        db.insertarMascota(contentValues);

        //con put guardamos los valores en la bse datos
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE,"Tobby");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAZA,"Labrador");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.ic4);
        //llamamos al metodo insertarmacota
        db.insertarMascota(contentValues);

        //con put guardamos los valores en la bse datos
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE,"Hacho");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAZA,"Pug");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.ic5);
        //llamamos al metodo insertarmacota
        db.insertarMascota(contentValues);
    }//insertar_mascotas

    public void darRatinMascota(Mascota mascota){
        //metodo para registrar los likes en la bd
        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_RATIN_MASCOTA_ID_MASCOTA,mascota.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_RATIN_MASCOTA_NUMERO_RATIN, RATING);
        //invocamos el metodo insertar para likes
        db.insertarRatinMascota(contentValues);
    }//dar like

    public int obtenerRatinMascota(Mascota mascota){
        //metodo para traer los likes de la bd
        BaseDatos db = new BaseDatos(context);
        return db.obtenerRatinMascota(mascota);
    }//obtenerlikes
}//constructormascota
