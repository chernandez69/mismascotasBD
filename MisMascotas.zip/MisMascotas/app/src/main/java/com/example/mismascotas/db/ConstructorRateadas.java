package com.example.mismascotas.db;

import android.content.ContentValues;
import android.content.Context;

import com.example.mismascotas.R;
import com.example.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public class ConstructorRateadas {
    private static final int RATING = 1;
    private Context context;
    //constructor mascota
    public ConstructorRateadas(Context context) {
        this.context=context;
    }
    public ArrayList<Mascota> obtenerDatos(){
        //instanciamos la clase base datos para traer las mascotas de la fuente
        BaseDatos db = new BaseDatos(context);
        return db.obtenerMascotasRateadas();
    }

    public int obtenerRatinMascota(Mascota mascota){
        //metodo para traer los likes de la bd
        BaseDatos db = new BaseDatos(context);
        return db.obtenerRatinMascota(mascota);
    }

}
