package com.example.mismascotas.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mismascotas.adapter.MascotaAdaptador;
import com.example.mismascotas.adapter.RateadasAdaptador;
import com.example.mismascotas.pojo.Mascota;
import com.example.mismascotas.R;
import com.example.mismascotas.presentador.RateadasViewFragmentPresenter;
import com.example.mismascotas.presentador.RecyclerViewFragmentPresenter;
import com.example.mismascotas.presentador.iRateadasViewFragmentPresenter;

import java.util.ArrayList;


public class RateadasViewFragment extends Fragment implements iRateadasViewFragmentView{
        private ArrayList<Mascota> mascotas;
        private RecyclerView listaMascotas;
        private iRateadasViewFragmentPresenter presenter;

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            //infllamos el fragment
            View v = inflater.inflate(R.layout.fragment_rateadas, container, false);
            //instanciamos el reciclerview
            listaMascotas = (RecyclerView) v.findViewById(R.id.rvMascotas2);
            //instanciamos el presentador
            presenter = new RateadasViewFragmentPresenter(this, getContext());
            return v;
            //return super.onCreateView(inflater, container, savedInstanceState);
        }

        @Override
        public void generarLinearLayoutVertical() {
            LinearLayoutManager glm = new LinearLayoutManager(getActivity());
            glm.setOrientation(LinearLayoutManager.VERTICAL);
            listaMascotas.setLayoutManager(glm);//hacemos que el reciclerview se porte como linearL
        }

        @Override
        public RateadasAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {
            RateadasAdaptador adaptador = new RateadasAdaptador(mascotas, getActivity());
            return adaptador;
        }

    @Override
    public void inicializarAdaptadorRV(RateadasAdaptador adaptador) {
        listaMascotas.setAdapter(adaptador);
    }


}//class