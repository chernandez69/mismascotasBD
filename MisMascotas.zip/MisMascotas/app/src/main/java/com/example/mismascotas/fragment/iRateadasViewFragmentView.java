package com.example.mismascotas.fragment;

import com.example.mismascotas.adapter.MascotaAdaptador;
import com.example.mismascotas.adapter.RateadasAdaptador;
import com.example.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public interface iRateadasViewFragmentView {
    public void generarLinearLayoutVertical();
    public RateadasAdaptador crearAdaptador(ArrayList<Mascota> mascotas);
    public void inicializarAdaptadorRV(RateadasAdaptador adaptador);
}
