package com.example.mismascotas.fragment;

import com.example.mismascotas.adapter.MascotaAdaptador;
import com.example.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public interface iRecyclerViewFragmentView {
    //metodos para generar el layout  el arraylist contactos
    //inicar el adaptador
    public void generarLinearLayoutVertical();
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador);
}
