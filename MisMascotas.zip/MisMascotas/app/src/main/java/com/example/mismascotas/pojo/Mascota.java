package com.example.mismascotas.pojo;

public class Mascota {
    private int id;
    private String nombre;
    private String raza;
    private int foto;
    private int ratin;


    public Mascota(int foto, String nombre, String raza, int ratin) {
        this.foto = foto;
        this.nombre = nombre;
        this.raza = raza;
        this.ratin = ratin;
    }//constructor

    public Mascota() {
        //vacio para el while recorrer bd
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getRatin() {
        return ratin;
    }

    public void setRatin(int ratin) {
        this.ratin = ratin;
    }

    public int getFoto() { return foto;   }

    public void setFoto(int foto) { this.foto = foto; }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
