package com.example.mismascotas.presentador;

import android.content.Context;

import com.example.mismascotas.db.ConstructorMascota;
import com.example.mismascotas.db.ConstructorRateadas;
import com.example.mismascotas.fragment.iRateadasViewFragmentView;
import com.example.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public class RateadasViewFragmentPresenter implements iRateadasViewFragmentPresenter{
    private iRateadasViewFragmentView iRateadasViewFragmentView;
    private Context context;
    private ConstructorRateadas constructorRateadas;
    private ArrayList<Mascota> mascotas;

    public RateadasViewFragmentPresenter(iRateadasViewFragmentView iRateadasViewFragmentView, Context context){
        this.iRateadasViewFragmentView=iRateadasViewFragmentView;
        this.context = context;
        obtenerMascotasRateadas();//obtener mascotas rateadas de ka bd
    }

    @Override
    public void obtenerMascotasRateadas() {
        //traer los datos
        constructorRateadas = new ConstructorRateadas(context);
        mascotas = constructorRateadas.obtenerDatos();
        //llamamos al mostrar contactos en el RV
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        iRateadasViewFragmentView.inicializarAdaptadorRV(iRateadasViewFragmentView.crearAdaptador(mascotas));
        iRateadasViewFragmentView.generarLinearLayoutVertical();
    }

}
