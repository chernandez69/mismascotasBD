package com.example.mismascotas.presentador;

import android.content.Context;
import com.example.mismascotas.fragment.iRecyclerViewFragmentView;
import com.example.mismascotas.db.ConstructorMascota;
import com.example.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public class RecyclerViewFragmentPresenter implements iRecyclerViewFragmentPresenter{
    private iRecyclerViewFragmentView iRecyclerViewFragmentView;
    private Context context;
    private ConstructorMascota constructorMascota;
    private ArrayList<Mascota> mascotas;

    public RecyclerViewFragmentPresenter(iRecyclerViewFragmentView iRecyclerViewFragmentView, Context context){
        this.iRecyclerViewFragmentView=iRecyclerViewFragmentView;
        this.context = context;
        obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        //traer los datos
        constructorMascota = new ConstructorMascota(context);
        mascotas = constructorMascota.obtenerDatos();
        //llamamos al mostrar contactos en el RV
        mostrarMascotasRV();
    }//obtener

    @Override
    public void mostrarMascotasRV() {
        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(mascotas));
        iRecyclerViewFragmentView.generarLinearLayoutVertical();
    }

}
