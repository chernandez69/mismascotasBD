package com.example.mismascotas.presentador;

public interface iRateadasViewFragmentPresenter {
    public void obtenerMascotasRateadas();
    public void mostrarMascotasRV();
}

