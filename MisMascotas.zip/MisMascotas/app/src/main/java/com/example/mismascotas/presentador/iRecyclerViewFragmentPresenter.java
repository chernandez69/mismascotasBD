package com.example.mismascotas.presentador;

public interface iRecyclerViewFragmentPresenter {
    //interface para obtener y presentar los datos en recyclerview
    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();
}

